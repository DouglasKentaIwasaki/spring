/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.prolic.lib;

/**
 *
 * @author kenta
 */
public class lib {

    /**
     * @param args the command line arguments
     */
    private static void main(String[] args) {
        // TODO code application logic here
    }
    public static String getVersao(){
        return "prolic.lib-0.1";
    }
    public static void printVersao(){
        System.out.println("\n\n\nprolic.lib-0.1\n\n");
    }
    
}
