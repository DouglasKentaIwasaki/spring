package com.prolic.lib.Controller;

import com.prolic.lib.Model.Usuario;
import com.prolic.lib.ModelView.UsuarioViewModel;

/**
 * Classe controladora de Usuários
 * @author kenta
 */
public class UsuarioController
{
    /**
     * Método para autenticação de usuários
     * @param cpf String - cpf do Usuário
     * @param senha String - senha do Usuário
     * @return positivo: UsuárioViewModel | negativo: null
     */
    public UsuarioViewModel autenticar(String cpf, String senha)
    {
        Usuario u = new Usuario().autenticar(cpf, senha);
        if (u != null){
            UsuarioViewModel usuariovm =  new UsuarioViewModel();
            usuariovm.setCodigo(u.getCodigo());
            usuariovm.setCargo(u.getCargo());
            usuariovm.setCpf(u.getCpf());
            usuariovm.setEmailInstitucional(u.getEmailInstitucional());
            usuariovm.setEmailPessoal(u.getEmailPessoal());
            usuariovm.setNome(u.getNome());
            usuariovm.setMatricura(u.getMatricura());
            usuariovm.setDtCriacao(u.getDtCriacao());
            usuariovm.setDtDesativacao(u.getDtDesativacao());
            usuariovm.setDtNascimento(u.getDtNascimento());
            usuariovm.setRg(u.getRg());
            usuariovm.setSetor(u.getSetor());
            usuariovm.setSenha(u.getSenha());

            usuariovm.setEntidade(new EntidadeController().obter(u.getCodigoEntidade()));
            usuariovm.setNivel(new NivelController().obter(u.getCodigoNivel()));

            return usuariovm;
        }
        else
            return null;
    }
    
    public UsuarioViewModel obter(String cpf)
    {
        Usuario u = new Usuario().obter(cpf);
        if (u != null){
            UsuarioViewModel usuariovm =  new UsuarioViewModel();
            usuariovm.setCodigo(u.getCodigo());
            usuariovm.setCargo(u.getCargo());
            usuariovm.setCpf(u.getCpf());
            usuariovm.setEmailInstitucional(u.getEmailInstitucional());
            usuariovm.setEmailPessoal(u.getEmailPessoal());
            usuariovm.setNome(u.getNome());
            usuariovm.setMatricura(u.getMatricura());
            usuariovm.setDtCriacao(u.getDtCriacao());
            usuariovm.setDtDesativacao(u.getDtDesativacao());
            usuariovm.setDtNascimento(u.getDtNascimento());
            usuariovm.setRg(u.getRg());
            usuariovm.setSetor(u.getSetor());
            usuariovm.setSenha(u.getSenha());

            usuariovm.setEntidade(new EntidadeController().obter(u.getCodigoEntidade()));
            usuariovm.setNivel(new NivelController().obter(u.getCodigoNivel()));

            return usuariovm;
        }
        else
            return null;
    }
    public int Gravar(UsuarioViewModel u)
    {
        return 2;
    }
}