/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.prolic.lib.Controller;

import com.prolic.lib.Model.Acesso;
import com.prolic.lib.ModelView.AcessoViewModel;
import java.util.ArrayList;

/**
 *
 * @author kenta
 */
public class AcessoController {
    public ArrayList<AcessoViewModel> obter(int codigoNivel) {
        ArrayList<Acesso> a = new Acesso().obter(codigoNivel);
        ArrayList<AcessoViewModel> acessosvm = new  ArrayList();
        if (a != null) {
            while(!a.isEmpty())
                acessosvm.add(modelToViewModel(a.remove(0)));
            return acessosvm;
        }
        return null;
    }
    private AcessoViewModel modelToViewModel(Acesso acesso){
        return new AcessoViewModel(acesso.getCodigo(), acesso.getDescricao());
    }
}
