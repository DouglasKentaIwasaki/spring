package com.prolic.lib.Controller;

import com.prolic.lib.Model.Endereco;
import com.prolic.lib.ModelView.EnderecoViewModel;

public class EnderecoController {
    public EnderecoViewModel obter(int codigo) {
        Endereco e = new Endereco().obter(codigo);
        if (e != null) {
            EnderecoViewModel enderecovm = new EnderecoViewModel();
            enderecovm.setCodigo(e.getCodigo());
            enderecovm.setLogradouro(e.getLogradouro());
            enderecovm.setNumero(e.getNumero());
            enderecovm.setComplemento(e.getComplemento());
            enderecovm.setBairro(e.getBairro());
            enderecovm.setCidade(e.getCidade());
            enderecovm.setEstado(e.getEstado());
            enderecovm.setCep(e.getCep());
            return enderecovm;
        }
        return null;
    }
}
