package com.prolic.lib.Controller;

import com.prolic.lib.Model.Nivel;
import com.prolic.lib.ModelView.NivelViewModel;


public class NivelController {

    public NivelViewModel obter(int codigo) {
        Nivel n = new Nivel().obter(codigo);
        if (n != null) {
            NivelViewModel nivelvm = new NivelViewModel();
            nivelvm.setCodigo(n.getCodigo());
            nivelvm.setNome(n.getNome());
            
            nivelvm.setAcessos(new AcessoController().obter(n.getCodigo()));
            
            return nivelvm;
        }
        return null;
    }
}
