package com.prolic.lib.Controller;

import com.prolic.Lib.Model.Entidade;
import com.prolic.lib.ModelView.EntidadeViewModel;


public class EntidadeController
    {
        public EntidadeViewModel obter(String cnpj)
        {
            Entidade e = new Entidade().obter(cnpj);
            if (e != null){
                EntidadeViewModel entidadevm = new EntidadeViewModel();
                entidadevm.setCnpj(e.getCnpj());
                entidadevm.setCodigo(e.getCodigo());
                entidadevm.setEmailInstitucional(e.getEmailInstitucional());
                entidadevm.setEmailLicitacao(e.getEmailLicitacao());
                entidadevm.setRazaoSocial(e.getRazaoSocial());
                entidadevm.setSite(e.getSite());
                entidadevm.setTelefone(e.getTelefone());
                return entidadevm;
            }
            else
                return null;
        }
        public EntidadeViewModel obter(int codigo)
        {
            Entidade e = new Entidade().obter(codigo);
            if (e != null){
                EntidadeViewModel entidadevm = new EntidadeViewModel();
                entidadevm.setCnpj(e.getCnpj());
                entidadevm.setCodigo(e.getCodigo());
                entidadevm.setEmailInstitucional(e.getEmailInstitucional());
                entidadevm.setEmailLicitacao(e.getEmailLicitacao());
                entidadevm.setRazaoSocial(e.getRazaoSocial());
                entidadevm.setSite(e.getSite());
                entidadevm.setTelefone(e.getTelefone());
                return entidadevm;
            }
            else
                return null;
        }
        public int Gravar(EntidadeViewModel e)
        {
            return 2;
        }
    }