package com.prolic.lib.ModelView;

import java.time.LocalDate;

public class UsuarioViewModel {
    private int codigo;
    private String matricura;
    private String nome;
    private String setor;
    private String cpf;
    private String cargo;
    private String emailInstitucional;
    private String emailPessoal;
    private String senha;
    private LocalDate dtCriacao;
    private LocalDate dtDesativacao;
    private EnderecoViewModel endereco;
    private String rg;
    private LocalDate dtNascimento;
    private NivelViewModel nivel;
    private EntidadeViewModel entidade;

    public UsuarioViewModel() {
        this.codigo = 0;
        this.matricura = "";
        this.nome = "";
        this.setor = "";
        this.cpf = "";
        this.cargo = "";
        this.emailInstitucional = "";
        this.emailPessoal = "";
        this.senha = "";
        this.dtCriacao = null;
        this.dtDesativacao = null;
        this.endereco = null;
        this.rg = "";
        this.dtNascimento = null;
        this.nivel = null;
        this.entidade = null;
    }

    public UsuarioViewModel(int codigo, String matricura, String nome, String setor, String cpf, String cargo, String emailInstitucional, String emailPessoal, String senha, LocalDate dtCriacao, LocalDate dtDesativacao, EnderecoViewModel endereco, String rg, LocalDate dtNascimento, NivelViewModel nivel, EntidadeViewModel entidade) {
        this.codigo = codigo;
        this.matricura = matricura;
        this.nome = nome;
        this.setor = setor;
        this.cpf = cpf;
        this.cargo = cargo;
        this.emailInstitucional = emailInstitucional;
        this.emailPessoal = emailPessoal;
        this.senha = senha;
        this.dtCriacao = dtCriacao;
        this.dtDesativacao = dtDesativacao;
        this.endereco = endereco;
        this.rg = rg;
        this.dtNascimento = dtNascimento;
        this.nivel = nivel;
        this.entidade = entidade;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getMatricura() {
        return matricura;
    }

    public void setMatricura(String matricura) {
        this.matricura = matricura;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSetor() {
        return setor;
    }

    public void setSetor(String setor) {
        this.setor = setor;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public String getEmailInstitucional() {
        return emailInstitucional;
    }

    public void setEmailInstitucional(String emailInstitucional) {
        this.emailInstitucional = emailInstitucional;
    }

    public String getEmailPessoal() {
        return emailPessoal;
    }

    public void setEmailPessoal(String emailPessoal) {
        this.emailPessoal = emailPessoal;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public LocalDate getDtCriacao() {
        return dtCriacao;
    }

    public void setDtCriacao(LocalDate dtCriacao) {
        this.dtCriacao = dtCriacao;
    }

    public LocalDate getDtDesativacao() {
        return dtDesativacao;
    }

    public void setDtDesativacao(LocalDate dtDesativacao) {
        this.dtDesativacao = dtDesativacao;
    }

    public EnderecoViewModel getEndereco() {
        return endereco;
    }

    public void setEndereco(EnderecoViewModel endereco) {
        this.endereco = endereco;
    }

    public String getRg() {
        return rg;
    }

    public void setRg(String rg) {
        this.rg = rg;
    }

    public LocalDate getDtNascimento() {
        return dtNascimento;
    }

    public void setDtNascimento(LocalDate dtNascimento) {
        this.dtNascimento = dtNascimento;
    }


    public NivelViewModel getNivel() {
        return nivel;
    }

    public void setNivel(NivelViewModel nivel) {
        this.nivel = nivel;
    }

    public EntidadeViewModel getEntidade() {
        return entidade;
    }

    public void setEntidade(EntidadeViewModel entidade) {
        this.entidade = entidade;
    }
    
    
}
