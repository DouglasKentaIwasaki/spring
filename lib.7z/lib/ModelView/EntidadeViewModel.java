package com.prolic.lib.ModelView;

import java.time.LocalDate;

public class EntidadeViewModel {
    private int codigo;
    private String cnpj;
    private String razaoSocial;
    private String telefone;
    private String site;
    private String emailInstitucional;
    private String emailLicitacao;
    private LocalDate dtCriacao;
    private LocalDate dtDesativacao;
    private EnderecoViewModel endereco;

    public EntidadeViewModel() {
        this.codigo = 0;
        this.cnpj = "";
        this.razaoSocial = "";
        this.telefone = "";
        this.site = "";
        this.emailInstitucional = "";
        this.emailLicitacao = "";
        this.dtCriacao = null;
        this.dtDesativacao = null;
        this.endereco = null;
    }

    public EntidadeViewModel(int codigo, String cnpj, String razaoSocial, String telefone, String site, String emailInstitucional, String emailLicitacao, LocalDate dtCriacao, LocalDate dtDesativacao, EnderecoViewModel endereco) {
        this.codigo = codigo;
        this.cnpj = cnpj;
        this.razaoSocial = razaoSocial;
        this.telefone = telefone;
        this.site = site;
        this.emailInstitucional = emailInstitucional;
        this.emailLicitacao = emailLicitacao;
        this.dtCriacao = dtCriacao;
        this.dtDesativacao = dtDesativacao;
        this.endereco = endereco;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public String getRazaoSocial() {
        return razaoSocial;
    }

    public void setRazaoSocial(String razaoSocial) {
        this.razaoSocial = razaoSocial;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getSite() {
        return site;
    }

    public void setSite(String site) {
        this.site = site;
    }

    public String getEmailInstitucional() {
        return emailInstitucional;
    }

    public void setEmailInstitucional(String emailInstitucional) {
        this.emailInstitucional = emailInstitucional;
    }

    public String getEmailLicitacao() {
        return emailLicitacao;
    }

    public void setEmailLicitacao(String emailLicitacao) {
        this.emailLicitacao = emailLicitacao;
    }

    public LocalDate getDtCriacao() {
        return dtCriacao;
    }

    public void setDtCriacao(LocalDate dtCriacao) {
        this.dtCriacao = dtCriacao;
    }

    public LocalDate getDtDesativacao() {
        return dtDesativacao;
    }

    public void setDtDesativacao(LocalDate dtDesativacao) {
        this.dtDesativacao = dtDesativacao;
    }

    public EnderecoViewModel getEndereco() {
        return endereco;
    }

    public void setEndereco(EnderecoViewModel endereco) {
        this.endereco = endereco;
    }
    
    
}
