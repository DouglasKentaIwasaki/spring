/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.prolic.lib.DAL;

import com.prolic.lib.Model.Endereco;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author kenta
 */

public class EnderecoDAO {
    public static int salvar(Endereco e) {
        int retorno = 0;
        String sql = null;
        sql = "insert into endereco(end_logradouro, end_numero, end_complemento, "
                + "end_bairro, end_cep, end_cidade, end_estado)"
                + "values(?,?,?,?,?,?,?);";
        try (Connection con = Conexao.abrir()) {
            if(con != null) {
                try(PreparedStatement ps = con.prepareStatement(sql)) {
                    ps.setString(1, e.getLogradouro());
                    ps.setString(2, e.getNumero());
                    ps.setString(3, e.getComplemento());
                    ps.setString(4, e.getBairro());
                    ps.setString(5, e.getCep());
                    ps.setString(6, e.getCidade());
                    ps.setString(7, e.getEstado());
                    
                    retorno = ps.executeUpdate();
                }
            }
        } catch (SQLException ex) {
            System.out.println("\n\n\nErro DAO: "+ex+"\n\n");
            retorno = -1;
        }
        return retorno;
    }  
    
    public static Endereco obter(int codigo) {
        Endereco e = null;
        String sql = "SELECT * FROM endereco WHERE end_codigo = ?;";
        try(Connection con = Conexao.abrir()) {
            if(con != null) {
                try(PreparedStatement ps = con.prepareStatement(sql)) {
                    ps.setInt(1, codigo);
                    try(ResultSet rs = ps.executeQuery()) {
                        if(rs.next()) {
                            e.setCodigo(rs.getInt("end_codigo"));
                            e.setLogradouro(rs.getString("end_logradouro"));
                            e.setNumero(rs.getString("end_numero"));
                            e.setComplemento(rs.getString("end_complemento"));
                            e.setBairro(rs.getString("end_bairro"));
                            e.setCep(rs.getString("end_cep"));
                            e.setCidade(rs.getString("end_cidade"));
                            e.setEstado(rs.getString("end_estado"));
                        }
                    } 
                }
            }
        } catch (SQLException ex) {
            System.out.println("\n\n\nErro DAO: "+ex+"\n\n");
        }
        return e;
    }
}
