/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.prolic.lib.DAL;

import com.prolic.Lib.Model.Entidade;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author kenta
 */
public class EntidadeDAO {
    public static int salvar(Entidade e) {
        int retorno = 0;
        String sql = null;
        sql = "insert into endereco "
                + "(ent_cnpj, ent_razao_social, ent_telefone, ent_site, "
                + " ent_email_institucional, ent_email_licitacao, ent_dt_criacao, "
                + " ent_dt_desativacao, end_codigo) "
                + " values(?, ?, ?, ?, ?, ?, ?, ?, ?);";
        try (Connection con = Conexao.abrir()) {
            if (con != null) {
                try (PreparedStatement ps = con.prepareStatement(sql)) {
                    ps.setString(1, e.getCnpj());
                    ps.setString(2, e.getRazaoSocial());
                    ps.setString(3, e.getTelefone());
                    ps.setString(4, e.getSite());
                    ps.setString(5, e.getEmailInstitucional());
                    ps.setString(6, e.getEmailLicitacao());
                    ps.setDate(7, Date.valueOf(e.getDtCriacao()));
                    ps.setDate(8, null);
                    ps.setInt(9, e.getCodigoEndereco());

                    retorno = ps.executeUpdate();
                }
            }
        } catch (SQLException ex) {
            System.out.println("\n\n\nErro DAO: " + ex + "\n\n");
            retorno = -1;
        }
        return retorno;
    }
    public static Entidade obter(int codigo) {
        Entidade e = null;
        String sql = "SELECT * FROM entidade WHERE ent_codigo = ?;";
        try (Connection con = Conexao.abrir()) {
            if (con != null) {
                try (PreparedStatement ps = con.prepareStatement(sql)) {
                    ps.setInt(1, codigo);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (rs.next()) {
                            e.setCodigo(rs.getInt("ent_codigo"));
                            e.setRazaoSocial(rs.getString("ent_razao_social"));
                            e.setTelefone(rs.getString("ent_telefone"));
                            e.setSite(rs.getString("ent_site"));
                            e.setEmailInstitucional(rs.getString("ent_email_institucional"));
                            e.setEmailLicitacao(rs.getString("ent_email_licitacao"));
                            e.setDtCriacao(rs.getDate("ent_dt_criacao").toLocalDate());
                            if (rs.getDate("ent_dt_desativacao") != null) {
                                e.setDtDesativacao(rs.getDate("ent_dt_desativacao").toLocalDate());
                            } else {
                                e.setDtDesativacao(null);
                            }
                            e.setCodigoEndereco(rs.getInt("end_codigo"));
                        }
                    }
                }
            }
        } catch (SQLException ex) {
            System.out.println("\n\n\nErro DAO: " + ex + "\n\n");
        }
        return e;
    }
    public static Entidade obter(String cnpj) {
        Entidade e = null;
        String sql = "SELECT * FROM entidade WHERE ent_cnpj = ?;";
        try (Connection con = Conexao.abrir()) {
            if (con != null) {
                try (PreparedStatement ps = con.prepareStatement(sql)) {
                    ps.setString(1, cnpj);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (rs.next()) {
                            e.setCodigo(rs.getInt("ent_codigo"));
                            e.setRazaoSocial(rs.getString("ent_razao_social"));
                            e.setTelefone(rs.getString("ent_telefone"));
                            e.setSite(rs.getString("ent_site"));
                            e.setEmailInstitucional(rs.getString("ent_email_institucional"));
                            e.setEmailLicitacao(rs.getString("ent_email_licitacao"));
                            e.setDtCriacao(rs.getDate("ent_dt_criacao").toLocalDate());
                            if (rs.getDate("ent_dt_desativacao") != null) {
                                e.setDtDesativacao(rs.getDate("ent_dt_desativacao").toLocalDate());
                            } else {
                                e.setDtDesativacao(null);
                            }
                            e.setCodigoEndereco(rs.getInt("end_codigo"));
                        }
                    }
                }
            }
        } catch (SQLException ex) {
            System.out.println("\n\n\nErro DAO: " + ex + "\n\n");
        }
        return e;
    }
}
