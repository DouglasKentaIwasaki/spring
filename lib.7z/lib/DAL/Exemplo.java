/*
public class AnimalDAO {
        
    
    public static int alterar(Animal a) {
        int retorno = 0;
        String sql = "update animal set "
                + "ani_nome = ?, "
                + "ani_cor = ?, "
                + "ani_dt_nascimento = ?, "
                + "ani_dt_falecimento = ?, "
                + "cli_codigo = ?, "
                + "rac_codigo = ?, "
                + "ani_img = ? "
                + "where ani_codigo = ?;";
        
        try(Connection con = Conexao.abrir()) {
            if(con != null) {
                try(PreparedStatement ps = con.prepareStatement(sql)) {
                    ps.setString(1, a.getNome());
                    ps.setString(2, a.getCor());
                    ps.setDate(3, Date.valueOf(a.getDtNascimento()));
                    if(a.getDtFalecimento()!=null)
                        ps.setDate(4, Date.valueOf(a.getDtFalecimento()));
                    else
                        ps.setDate(4, null);
                    ps.setInt(5, a.getClienteCodigo());
                    ps.setInt(6, a.getRacaCodigo());
                    ps.setString(7, a.getFoto());
                    ps.setInt(8, a.getCodigo());
                    
                    retorno = ps.executeUpdate();
                }
            }
        } catch (SQLException ex) {
            System.out.println("\n\n\n"+ex+"\n\n\n");
            retorno = -1;
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return retorno;
    }
      
    public static Animal obter(int codigo) {
        Animal a = null;
        String sql = "SELECT * FROM animal WHERE ani_codigo = ?  ORDER BY ani_nome;";
        try(Connection con = Conexao.abrir()) {
            if(con != null) {
                try(PreparedStatement ps = con.prepareStatement(sql)) {
                    ps.setInt(1, codigo);
                   
                    try(ResultSet rs = ps.executeQuery()) {
                        if(rs.next()) {
                            a = new Animal();
                            a.setCodigo(rs.getInt("ani_codigo"));
                            a.setNome(rs.getString("ani_nome"));
                            a.setCor(rs.getString("ani_cor"));
                            a.setDtNascimento(rs.getDate("ani_dt_nascimento").toLocalDate());
                            if(rs.getDate("ani_dt_falecimento")!=null)
                                a.setDtFalecimento(rs.getDate("ani_dt_falecimento").toLocalDate());
                            else
                                a.setDtFalecimento(null);
                            a.setClienteCodigo(rs.getInt("cli_codigo"));
                            a.setRacaCodigo(rs.getInt("rac_codigo"));
                            a.setFoto(rs.getString("ani_img"));
                        }
                    } 
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return a;
    }
    public static ArrayList<Animal> obterAtivos(String animal, String cliente ) {
        ArrayList<Animal> animais = new ArrayList();
        String sql = "SELECT * FROM animal "
                + "INNER JOIN cliente "
                + "ON animal.cli_codigo = cliente.cli_codigo "
                + "AND animal.ani_nome like ? "
                + "AND animal.ani_dt_falecimento IS NULL "
                + "AND cliente.cli_nome like ? "
                + "AND cliente.cli_dt_desativacao IS NULL "
                + "INNER JOIN raca "
                + "ON animal.rac_codigo = raca.rac_codigo "
                + "ORDER BY ani_nome;";
        try(Connection con = Conexao.abrir()) {
            if(con != null) {
                try(PreparedStatement ps = con.prepareStatement(sql)) {
                    ps.setString(1, "%"+animal+"%");
                    ps.setString(2, "%"+cliente+"%");
                    try(ResultSet rs = ps.executeQuery()) {
                        while(rs.next()) {
                            Animal a = new Animal();
                            a.setCodigo(rs.getInt("ani_codigo"));
                            a.setNome(rs.getString("ani_nome"));
                            a.setCor(rs.getString("ani_cor"));
                            a.setDtNascimento(rs.getDate("ani_dt_nascimento").toLocalDate());
                            if(rs.getDate("ani_dt_falecimento")!=null)
                                a.setDtFalecimento(rs.getDate("ani_dt_falecimento").toLocalDate());
                            else
                                a.setDtFalecimento(null);
                            a.setClienteCodigo(rs.getInt("cli_codigo"));
                            a.setRacaCodigo(rs.getInt("rac_codigo"));
                            a.setFoto(rs.getString("ani_img"));
                            
                            a.getCliente().setCodigo(rs.getInt("cli_codigo"));
                            a.getCliente().setNome(rs.getString("cli_nome"));
                            if(rs.getDate("cli_dt_desativacao")!=null)
                                a.getCliente().setDesativacao(rs.getDate("cli_dt_desativacao").toLocalDate());
                            else
                                a.getCliente().setDesativacao(null);
                            
                            a.getRaca().setCodigo(rs.getInt("rac_codigo"));
                            a.getRaca().setNome(rs.getString("rac_nome"));
                            a.getRaca().setPorte(rs.getString("rac_porte"));
                            
                            
                            a.setC(a.getCliente().getNome());
                            a.setR(a.getRaca().getNome());
                            animais.add(a);
                        }
                    } 
                    catch(SQLException ex){
            System.out.println("\n\n\n\n"+ex+"\n\n\n");
                        System.out.println(ex.getMessage());
                    }
                }
            }
        } catch (SQLException ex) {
            System.out.println("\n\n\n\n"+ex+"\n\n\n");
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return animais;
    }
    public static ArrayList<Animal> obterInativos(String animal, String cliente ) {
        ArrayList<Animal> animais = new ArrayList();
        String sql = "SELECT * FROM animal "
                + "LEFT JOIN cliente "
                + "ON animal.cli_codigo = cliente.cli_codigo "
                + "AND animal.ani_nome like ? "
                + "AND cliente.cli_nome like ? "
                + "LEFT JOIN raca "
                + "ON animal.rac_codigo = raca.rac_codigo "
                + "WHERE animal.ani_dt_falecimento IS NOT NULL "
                + "OR cliente.cli_dt_desativacao IS NOT NULL "
                + "ORDER BY ani_nome;";
        try(Connection con = Conexao.abrir()) {
            if(con != null) {
                try(PreparedStatement ps = con.prepareStatement(sql)) {
                    ps.setString(1, "%"+animal+"%");
                    ps.setString(2, "%"+cliente+"%");
                    try(ResultSet rs = ps.executeQuery()) {
                        while(rs.next()) {
                            Animal a = new Animal();
                            a.setCodigo(rs.getInt("ani_codigo"));
                            a.setNome(rs.getString("ani_nome"));
                            a.setCor(rs.getString("ani_cor"));
                            a.setDtNascimento(rs.getDate("ani_dt_nascimento").toLocalDate());
                            if(rs.getDate("ani_dt_falecimento")!=null)
                                a.setDtFalecimento(rs.getDate("ani_dt_falecimento").toLocalDate());
                            else
                                a.setDtFalecimento(null);
                            a.setClienteCodigo(rs.getInt("cli_codigo"));
                            a.setRacaCodigo(rs.getInt("rac_codigo"));
                            a.setFoto(rs.getString("ani_img"));
                            
                            a.getCliente().setCodigo(rs.getInt("cli_codigo"));
                            a.getCliente().setNome(rs.getString("cli_nome"));
                            if(rs.getDate("cli_dt_desativacao")!=null)
                                a.getCliente().setDesativacao(rs.getDate("cli_dt_desativacao").toLocalDate());
                            else
                                a.getCliente().setDesativacao(null);
                            
                            a.getRaca().setCodigo(rs.getInt("rac_codigo"));
                            a.getRaca().setNome(rs.getString("rac_nome"));
                            a.getRaca().setPorte(rs.getString("rac_porte"));
                            
                            
                            a.setC(a.getCliente().getNome());
                            a.setR(a.getRaca().getNome());
                            animais.add(a);
                        }
                    } 
                    catch(SQLException ex){
                        System.out.println(ex.getMessage());
                    }
                }
            }
        } catch (SQLException ex) {
            System.out.println("\n\n\n\n"+ex+"\n\n\n");
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return animais;
    }
    
     
    public static int ativar(int codigo) {
        int retorno = 0;
        String sql = "update animal set "
                + "ani_dt_falecimento = ? "
                + "where ani_codigo = ?;";
        try(Connection con = Conexao.abrir()) {
            if(con != null) {
                try(PreparedStatement ps = con.prepareStatement(sql)) {
                    ps.setDate(1, null);
                    ps.setInt(2, codigo);
                    retorno = ps.executeUpdate();
                }
            }
        } catch (SQLException ex) {

            retorno = -1;
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return retorno;
    }
        public static Animal obterUltimo() {
        Animal a = null;
        String sql = "SELECT * FROM animal ";
        try(Connection con = Conexao.abrir()) {
            if(con != null) {
                try(PreparedStatement ps = con.prepareStatement(sql)) {
                    try(ResultSet rs = ps.executeQuery()) {
                        while(rs.next()) {
                            a = new Animal();
                            a.setCodigo(rs.getInt("ani_codigo"));
                            a.setNome(rs.getString("ani_nome"));
                            a.setCor(rs.getString("ani_cor"));
                            a.setDtNascimento(rs.getDate("ani_dt_nascimento").toLocalDate());
                            if(rs.getDate("ani_dt_falecimento")!=null)
                                a.setDtFalecimento(rs.getDate("ani_dt_falecimento").toLocalDate());
                            else
                                a.setDtFalecimento(null);
                            a.setClienteCodigo(rs.getInt("cli_codigo"));
                            a.setRacaCodigo(rs.getInt("rac_codigo"));
                            a.setFoto(rs.getString("ani_img"));
                            
                            a.getCliente().setCodigo(rs.getInt("cli_codigo"));
                            a.getCliente().setNome(rs.getString("cli_nome"));
                            if(rs.getDate("cli_dt_desativacao")!=null)
                                a.getCliente().setDesativacao(rs.getDate("cli_dt_desativacao").toLocalDate());
                            else
                                a.getCliente().setDesativacao(null);
                            
                            a.getRaca().setCodigo(rs.getInt("rac_codigo"));
                            a.getRaca().setNome(rs.getString("rac_nome"));
                            a.getRaca().setPorte(rs.getString("rac_porte"));
                            
                            
                            a.setC(a.getCliente().getNome());
                            a.setR(a.getRaca().getNome());
                        }
                    } 
                    catch(SQLException ex){
            System.out.println("\n\n\n\n"+ex+"\n\n\n");
                        System.out.println(ex.getMessage());
                    }
                }
            }
        } catch (SQLException ex) {
            System.out.println("\n\n\n\n"+ex+"\n\n\n");
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return a;
    }
    
}
*/