/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.prolic.lib.DAL;

import com.prolic.lib.Model.Usuario;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author kenta
 */
public class UsuarioDAO {

    public static int salvar(Usuario u) {
        int retorno = 0;
        String sql = null;
        sql = "insert into usuario "
                + "(usu_matricula, usu_nome, usu_setor, usu_cpf, "
                + " usu_cargo, usu_email_institucional, usu_dt_criacao, "
                + " usu_dt_desativacao, usu_senha,  niv_codigo, ent_codigo) "
                + " values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
        try (Connection con = Conexao.abrir()) {
            if (con != null) {
                try (PreparedStatement ps = con.prepareStatement(sql)) {
                    ps.setString(1, u.getMatricura());
                    ps.setString(2, u.getNome());
                    ps.setString(3, u.getSetor());
                    ps.setString(4, u.getCpf());
                    ps.setString(5, u.getCargo());
                    ps.setString(6, u.getEmailInstitucional());
                    ps.setDate(7, Date.valueOf(u.getDtCriacao()));
                    ps.setDate(8, null);
                    ps.setInt(9, u.getCodigoNivel());
                    ps.setInt(10, u.getCodigoEntidade());

                    retorno = ps.executeUpdate();
                }
            }
        } catch (SQLException ex) {
            System.out.println("\n\n\nErro DAO: " + ex + "\n\n");
            retorno = -1;
        }
        return retorno;
    }

    public static Usuario obter(String cpf) {
        Usuario u = null;
        String sql = "SELECT * FROM usuario WHERE usu_cpf = ?;";
        try (Connection con = Conexao.abrir()) {
            if (con != null) {
                try (PreparedStatement ps = con.prepareStatement(sql)) {
                    ps.setString(1, cpf);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (rs.next()) {
                            u.setCodigo(rs.getInt("ent_codigo"));
                            u.setMatricura(rs.getString("ent_codigo"));
                            u.setNome(rs.getString("usu_nome"));
                            u.setSetor(rs.getString("usu_setor"));
                            u.setCpf(rs.getString("usu_cpf"));
                            u.setCargo(rs.getString("usu_cargo"));
                            u.setEmailInstitucional(rs.getString("usu_email_institucional"));
                            u.setDtCriacao(rs.getDate("usu_dt_criacao").toLocalDate());
                            if (rs.getDate("usu_dt_desativacao") != null) {
                                u.setDtDesativacao(rs.getDate("usu_dt_desativacao").toLocalDate());
                            } else {
                                u.setDtDesativacao(null);
                            }
                            u.setSenha(rs.getString("usu_senha"));
                            u.setCodigoNivel(rs.getInt("niv_codigo"));
                            u.setCodigoEntidade(rs.getInt("ent_codigo"));
                        }
                    }
                }
            }
        } catch (SQLException ex) {
            System.out.println("\n\n\nErro DAO: " + ex + "\n\n");
        }
        return u;
    }
    
    public static Usuario autenticar(String cpf, String senha) {
        Usuario u = null;
        String sql = "SELECT * FROM usuario WHERE usu_cpf = ? AND usu_senha = ?;";
        try (Connection con = Conexao.abrir()) {
            if (con != null) {
                try (PreparedStatement ps = con.prepareStatement(sql)) {
                    ps.setString(1, cpf);
                    ps.setString(2, senha);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (rs.next()) {
                            u.setCodigo(rs.getInt("ent_codigo"));
                            u.setMatricura(rs.getString("ent_codigo"));
                            u.setNome(rs.getString("usu_nome"));
                            u.setSetor(rs.getString("usu_setor"));
                            u.setCpf(rs.getString("usu_cpf"));
                            u.setCargo(rs.getString("usu_cargo"));
                            u.setEmailInstitucional(rs.getString("usu_email_institucional"));
                            u.setDtCriacao(rs.getDate("usu_dt_criacao").toLocalDate());
                            if (rs.getDate("usu_dt_desativacao") != null) {
                                u.setDtDesativacao(rs.getDate("usu_dt_desativacao").toLocalDate());
                            } else {
                                u.setDtDesativacao(null);
                            }
                            u.setSenha(rs.getString("usu_senha"));
                            u.setCodigoNivel(rs.getInt("niv_codigo"));
                            u.setCodigoEntidade(rs.getInt("ent_codigo"));
                        }
                    }
                }
            }
        } catch (SQLException ex) {
            System.out.println("\n\n\nErro DAO: " + ex + "\n\n");
        }
        return u;
    }

}
