/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.prolic.lib.DAL;

import com.prolic.Lib.Model.Entidade;
import com.prolic.lib.Model.Nivel;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author kenta
 */
public class NivelDAO {

    public static Nivel obter(int codigo) {
        Nivel n = null;
        String sql = "SELECT * FROM nivel WHERE niv_codigo = ?;";
        try (Connection con = Conexao.abrir()) {
            if (con != null) {
                try (PreparedStatement ps = con.prepareStatement(sql)) {
                    ps.setInt(1, codigo);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (rs.next()) {
                            n.setCodigo(rs.getInt("niv_codigo"));
                            n.setNome(rs.getString("niv_nome"));
                        }
                    }
                }
            }
        } catch (SQLException ex) {
            System.out.println("\n\n\nErro DAO: " + ex + "\n\n");
        }
        return n;
    }

    public static Nivel obter(String nome) {
        Nivel n = null;
        String sql = "SELECT * FROM nivel WHERE niv_nome = ?;";
        try (Connection con = Conexao.abrir()) {
            if (con != null) {
                try (PreparedStatement ps = con.prepareStatement(sql)) {
                    ps.setString(1, nome);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (rs.next()) {
                            n.setCodigo(rs.getInt("niv_codigo"));
                            n.setNome(rs.getString("niv_nome"));
                        }
                    }
                }
            }
        } catch (SQLException ex) {
            System.out.println("\n\n\nErro DAO: " + ex + "\n\n");
        }
        return n;
    }
}
