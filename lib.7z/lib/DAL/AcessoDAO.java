/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.prolic.lib.DAL;

import com.prolic.Lib.Model.Entidade;
import com.prolic.lib.Model.Acesso;
import com.prolic.lib.Model.Nivel;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author kenta
 */
public class AcessoDAO {
/*
    public static Nivel obter(int codigo) {
        Nivel n = null;
        String sql = "SELECT * FROM nivel WHERE niv_codigo = ?;";
        try (Connection con = Conexao.abrir()) {
            if (con != null) {
                try (PreparedStatement ps = con.prepareStatement(sql)) {
                    ps.setInt(1, codigo);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (rs.next()) {
                            n.setCodigo(rs.getInt("niv_codigo"));
                            n.setNome(rs.getString("niv_nome"));
                        }
                    }
                }
            }
        } catch (SQLException ex) {
            System.out.println("\n\n\nErro DAO: " + ex + "\n\n");
        }
        return n;
    }*/

    public static ArrayList<Acesso> obter(int codigoNivel) {
        ArrayList<Acesso> acessos = new ArrayList<>();
        String sql = "SELECT * FROM nivel "
                + "   INNER JOIN nivel_acesso "
                + "   ON nivel.niv_codigo = nivel_acesso.niv_codigo "
                + "   INNER JOIN acesso "
                + "   ON nivel_acesso.ace_codigo = acesso.ace_codigo "
                + "   WHERE nivel.niv_codigo = ?;";
        try (Connection con = Conexao.abrir()) {
            if (con != null) {
                try (PreparedStatement ps = con.prepareStatement(sql)) {
                    ps.setInt(1, codigoNivel);
                    try (ResultSet rs = ps.executeQuery()) {
                        while (rs.next()) {
                            Acesso a = new Acesso();
                            a.setCodigo(rs.getInt("ace_codigo"));
                            a.setDescricao(rs.getString("ace_descricao"));
                            acessos.add(a);
                        }
                    }
                }
            }
        } catch (SQLException ex) {
            System.out.println("\n\n\nErro DAO: " + ex + "\n\n");
        }
        return acessos;
    }
}
