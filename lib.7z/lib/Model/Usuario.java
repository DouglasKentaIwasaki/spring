package com.prolic.lib.Model;

import com.prolic.lib.DAL.UsuarioDAO;
import com.prolic.lib.Util.Valida;
import java.time.LocalDate;

public class Usuario {

    private int codigo;
    private String matricura;
    private String nome;
    private String setor;
    private String cpf;
    private String cargo;
    private String emailInstitucional;
    private String emailPessoal;
    private String senha;
    private LocalDate dtCriacao;
    private LocalDate dtDesativacao;
    private int codigoEndereco;
    private String rg;
    private int codigoEntidade;
    private LocalDate dtNascimento;
    private int codigoNivel;

    public Usuario() {
        this.codigo = 0;
        this.matricura = "";
        this.nome = "";
        this.setor = "";
        this.cpf = "";
        this.cargo = "";
        this.emailInstitucional = "";
        this.emailPessoal = "";
        this.senha = "";
        this.dtCriacao = null;
        this.dtDesativacao = null;
        this.codigoEndereco = 0;
        this.rg = "";
        this.codigoEntidade = 0;
        this.dtNascimento = null;
        this.codigoNivel = 0;
    }

    public Usuario(int codigo, String matricura, String nome, String setor, String cpf, String cargo, String emailInstitucional, String emailPessoal, String senha, LocalDate dtCriacao, LocalDate dtDesativacao, int codigoEndereco, String rg, int codigoEntidade, LocalDate dtNascimento, int codigoNivel) {
        this.codigo = codigo;
        this.matricura = matricura;
        this.nome = nome;
        this.setor = setor;
        this.cpf = cpf;
        this.cargo = cargo;
        this.emailInstitucional = emailInstitucional;
        this.emailPessoal = emailPessoal;
        this.senha = senha;
        this.dtCriacao = dtCriacao;
        this.dtDesativacao = dtDesativacao;
        this.codigoEndereco = codigoEndereco;
        this.rg = rg;
        this.codigoEntidade = codigoEntidade;
        this.dtNascimento = dtNascimento;
        this.codigoNivel = codigoNivel;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getMatricura() {
        return matricura;
    }

    public void setMatricura(String matricura) {
        this.matricura = matricura;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSetor() {
        return setor;
    }

    public void setSetor(String setor) {
        this.setor = setor;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public String getEmailInstitucional() {
        return emailInstitucional;
    }

    public void setEmailInstitucional(String emailInstitucional) {
        this.emailInstitucional = emailInstitucional;
    }

    public String getEmailPessoal() {
        return emailPessoal;
    }

    public void setEmailPessoal(String emailPessoal) {
        this.emailPessoal = emailPessoal;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public LocalDate getDtCriacao() {
        return dtCriacao;
    }

    public void setDtCriacao(LocalDate dtCriacao) {
        this.dtCriacao = dtCriacao;
    }

    public LocalDate getDtDesativacao() {
        return dtDesativacao;
    }

    public void setDtDesativacao(LocalDate dtDesativacao) {
        this.dtDesativacao = dtDesativacao;
    }

    public int getCodigoEndereco() {
        return codigoEndereco;
    }

    public void setCodigoEndereco(int codigoEndereco) {
        this.codigoEndereco = codigoEndereco;
    }

    public String getRg() {
        return rg;
    }

    public void setRg(String rg) {
        this.rg = rg;
    }

    public int getCodigoEntidade() {
        return codigoEntidade;
    }

    public void setCodigoEntidade(int codigoEntidade) {
        this.codigoEntidade = codigoEntidade;
    }

    public LocalDate getDtNascimento() {
        return dtNascimento;
    }

    public void setDtNascimento(LocalDate dtNascimento) {
        this.dtNascimento = dtNascimento;
    }

    public int getCodigoNivel() {
        return codigoNivel;
    }

    public void setCodigoNivel(int codigoNivel) {
        this.codigoNivel = codigoNivel;
    }

    public Usuario obter(String cpf) {
        if (Valida.cpf(cpf)) {
            return new UsuarioDAO().obter(cpf);
        }
        return null;
    }

    public Usuario autenticar(String cpf, String senha) {
        if (Valida.cpf(cpf) && !senha.isEmpty())
            return new Usuario().autenticar(cpf, senha);
        return null;
    }
}
