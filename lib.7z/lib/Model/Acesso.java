/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.prolic.lib.Model;

import com.prolic.lib.DAL.AcessoDAO;
import java.util.ArrayList;

/**
 *
 * @author kenta
 */
public class Acesso {
    private int codigo;
    private String descricao;

    public Acesso() {
        this.codigo = 0;
        this.descricao = "";
    }

    public Acesso(int codigo, String descricao) {
        this.codigo = codigo;
        this.descricao = descricao;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
    
    public ArrayList<Acesso> obter(int codigoNivel){
        if(codigoNivel > 0)
            return new AcessoDAO().obter(codigoNivel);
        return null;
    }
}
