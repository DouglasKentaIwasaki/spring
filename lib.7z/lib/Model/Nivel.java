package com.prolic.lib.Model;

import com.prolic.lib.ModelView.AcessoViewModel;
import java.util.ArrayList;


public class Nivel {

    private int codigo;
    private String nome;

    public Nivel() {
        this.codigo = 0;
        this.nome = "";
    }

    public Nivel(int codigo, String nome) {
        this.codigo = codigo;
        this.nome = nome;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return this.nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Nivel obter(int codigo) {
        return new Nivel();
    }

}

