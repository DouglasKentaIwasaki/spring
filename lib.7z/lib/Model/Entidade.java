package com.prolic.Lib.Model;

import com.prolic.lib.DAL.EntidadeDAO;
import com.prolic.lib.Util.Valida;
import java.time.LocalDate;

public class Entidade {
    private int codigo;
    private String cnpj;
    private String razaoSocial;
    private String telefone;
    private String site;
    private String emailInstitucional;
    private String emailLicitacao;
    private LocalDate dtCriacao;
    private LocalDate dtDesativacao;
    private int codigoEndereco;

    public Entidade() {
        this.codigo = 0;
        this.cnpj = "";
        this.razaoSocial = "";
        this.telefone = "";
        this.site = "";
        this.emailInstitucional = "";
        this.emailLicitacao = "";
        this.dtCriacao = null;
        this.dtDesativacao = null;
        this.codigoEndereco = 0;
    }
    public Entidade(int codigo, String cnpj, String razaoSocial, String telefone, String site, String emailInstitucional, String emailLicitacao, LocalDate dtCriacao, LocalDate dtDesativacao, int codigoEndereco) {
        this.codigo = codigo;
        this.cnpj = cnpj;
        this.razaoSocial = razaoSocial;
        this.telefone = telefone;
        this.site = site;
        this.emailInstitucional = emailInstitucional;
        this.emailLicitacao = emailLicitacao;
        this.dtCriacao = dtCriacao;
        this.dtDesativacao = dtDesativacao;
        this.codigoEndereco = codigoEndereco;
    }

    public int getCodigo() {
        return codigo;
    }
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }
    public String getCnpj() {
        return cnpj;
    }
    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }
    public String getRazaoSocial() {
        return razaoSocial;
    }
    public void setRazaoSocial(String razaoSocial) {
        this.razaoSocial = razaoSocial;
    }
    public String getTelefone() {
        return telefone;
    }
    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }
    public String getSite() {
        return site;
    }
    public void setSite(String site) {
        this.site = site;
    }
    public String getEmailInstitucional() {
        return emailInstitucional;
    }
    public void setEmailInstitucional(String emailInstitucional) {
        this.emailInstitucional = emailInstitucional;
    }
    public String getEmailLicitacao() {
        return emailLicitacao;
    }
    public void setEmailLicitacao(String emailLicitacao) {
        this.emailLicitacao = emailLicitacao;
    }
    public LocalDate getDtCriacao() {
        return dtCriacao;
    }
    public void setDtCriacao(LocalDate dtCriacao) {
        this.dtCriacao = dtCriacao;
    }
    public LocalDate getDtDesativacao() {
        return dtDesativacao;
    }
    public void setDtDesativacao(LocalDate dtDesativacao) {
        this.dtDesativacao = dtDesativacao;
    }
    public int getCodigoEndereco() {
        return codigoEndereco;
    }
    public void setCodigoEndereco(int codigoEndereco) {
        this.codigoEndereco = codigoEndereco;
    }
  
    public Entidade obter(String cnpj){
        if(Valida.cnpj(cnpj))
            return new EntidadeDAO().obter(cnpj);
        return null;
    } 
    public Entidade obter(int codigo){
        if(codigo > 0)
            return new EntidadeDAO().obter(codigo);
        return null;
    }
}
