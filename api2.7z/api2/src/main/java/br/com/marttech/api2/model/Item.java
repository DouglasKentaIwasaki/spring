package br.com.marttech.api2.model;


public class Item {
	private long id;
	private int quantidade;
	private double valorTotal;
	private Produto produto;
	public Item() {
		this.id = 0;
		this.quantidade = 0;
		this.valorTotal = 0;
		this.produto = null;
	}
	public Item(long id, int quantidade, double valorTotal, Produto produto) {
		this.id = id;
		this.quantidade = quantidade;
		this.valorTotal = valorTotal;
		this.produto = produto;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public int getQuantidade() {
		return quantidade;
	}
	public void setQuantidade(int quantidade) {
		this.quantidade = quantidade;
	}
	public double getValorTotal() {
		return valorTotal;
	}
	public void setValorTotal(double valorTotal) {
		this.valorTotal = valorTotal;
	}
	public Produto getProduto() {
		return produto;
	}
	public void setProduto(Produto produto) {
		this.produto = produto;
	}
	
	public List<Itens> obterPorIdCarrinho(long idCarrinho){
		return new ItemDAO().obterPorIdCarrinho(long idCarrinho);
	}

}
