package br.com.marttech.api2.controller;

import java.util.ArrayList;
import java.util.List;
import br.com.marttech.api2.dal.Banco;
import br.com.marttech.api2.model.*;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



@RestController
@RequestMapping("/api/carrinho")
public class CarrinhoController {
	
	@GetMapping("/{id}")
	public Carrinho listaPessoas(@RequestBody Long id){
		if (!Banco.getInstance().open()) 
			return null;
		
        Carrinho carrinho = new Carrinho().obterPorId(id);
        carrinho.setItens(new Item().obterPorIdCarrinho(id));
        
        Banco.getInstance().close();
        
        return carrinho;
	}
	
}
