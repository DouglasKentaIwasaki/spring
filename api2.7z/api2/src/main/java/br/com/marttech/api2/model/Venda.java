package br.com.marttech.api2.model;

import java.util.List;

public class Venda {
	private long id;
	private double valorTotal;
	private List<Item> itens;
	private Cliente cliente;
	public Venda() {
		this.id = 0;
		this.valorTotal = 0;
		this.itens = null;
		this.cliente = null;
	}
	public Venda(long id, double valorTotal, List<Item> itens, Cliente cliente) {
		this.id = id;
		this.valorTotal = valorTotal;
		this.itens = itens;
		this.cliente = cliente;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public double getValorTotal() {
		return valorTotal;
	}
	public void setValorTotal(double valorTotal) {
		this.valorTotal = valorTotal;
	}
	public List<Item> getItens() {
		return itens;
	}
	public void setItens(List<Item> itens) {
		this.itens = itens;
	}
	public Cliente getCliente() {
		return cliente;
	}
	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}
}
