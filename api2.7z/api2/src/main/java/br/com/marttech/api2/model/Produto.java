package br.com.marttech.api2.model;

public class Produto {
	private long id;
	private String nome;
	private String descricao;
	private String imagem;
	private double valor;

	public Produto() {
		this.id = 0;
		this.nome = "";
		this.descricao = "";
		this.imagem = "";
		this.valor = 0;
	}
	public Produto(long id, String nome, String descricao, String imagem, double valor) {
		this.id = id;
		this.nome = nome;
		this.descricao = descricao;
		this.imagem = imagem;
		this.valor = valor;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	public String getImagem() {
		return imagem;
	}
	public void setImagem(String imagem) {
		this.imagem = imagem;
	}
	public double getValor() {
		return valor;
	}
	public void setValor(double valor) {
		this.valor = valor;
	}
	
	
}
