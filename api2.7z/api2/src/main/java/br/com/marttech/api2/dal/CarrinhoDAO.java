package br.com.marttech.api2.dal;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import br.com.marttech.api2.model.Carrinho;

public class CarrinhoDAO {
	public Carrinho obterPorId(long id) {
		if (Banco.getInstance().getConnection() == null || id <= 0)
			return null;
	    String sql = "select * from carrinho where id = ?;";
	    try (PreparedStatement ps = Banco.getInstance().getConnection().prepareStatement(sql)) {
	        ps.setLong(1, id);
	        try(ResultSet rs = ps.executeQuery()) {
	            if (rs.next()) {
	                return new Carrinho(
		                    rs.getLong("id"),    
		                    rs.getDouble("valor_total"),
		                    null
	                );
	            } else {
	                return null;
	            }
	        }
	    } catch (SQLException ex)  {
	        System.out.println(ex.getMessage());
	        return null;
	    }
	}

	public int gravar(Carrinho carrinho) {
		int result = -10;
        String sql = ""
                + "insert "
                + "into carrinho (id, valor_total)"
                + "values(?,?) returning pag_id;";

        if (Banco.getInstance().getConnection() != null) {
            try (PreparedStatement ps = Banco.getInstance().getConnection().prepareStatement(sql)) {
                ps.setLong(1, carrinho.getId());
                ps.setDouble(2, carrinho.getValorTotal());

                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        result = rs.getInt("id");
                    }
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
        }

        return result;
	}
}
