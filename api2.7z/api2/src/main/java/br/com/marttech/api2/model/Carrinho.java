package br.com.marttech.api2.model;
import java.util.List;
import br.com.marttech.api2.dal.CarrinhoDAO;

public class Carrinho {
	private long id;
	private double valorTotal;
	private List<Item> itens;
	
	public Carrinho() {
		this.id = 0;
		this.valorTotal = 0;
		this.itens = null;
	}
	public Carrinho(long id, double valorTotal, List<Item> itens) {
		this.id = id;
		this.valorTotal = valorTotal;
		this.itens = itens;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public double getValorTotal() {
		return valorTotal;
	}
	public void setValorTotal(double valorTotal) {
		this.valorTotal = valorTotal;
	}
	public List<Item> getItens() {
		return itens;
	}
	public void setItens(List<Item> itens) {
		this.itens = itens;
	}
	public Carrinho obterPorId(long id) {
		return new CarrinhoDAO().obterPorId(id);
	}
	
}
